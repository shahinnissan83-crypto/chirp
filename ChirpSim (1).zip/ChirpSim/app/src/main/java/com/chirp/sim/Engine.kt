package com.chirp.sim

import kotlin.random.Random

/**
 * Abstraction over "who writes the text".
 * Step 1 = TemplateGenerator (offline, no model).
 * Step 4 = a LlamaGenerator (llama.cpp + Gemma GGUF) will implement this same interface.
 */
interface TextGenerator {
    suspend fun post(p: Persona): String
    suspend fun reply(p: Persona, target: String, thread: List<String>): String
}

object TemplateGenerator : TextGenerator {
    override suspend fun post(p: Persona) = Engine.post(p)
    override suspend fun reply(p: Persona, target: String, thread: List<String>) = Engine.reply(p, target)
}

object Engine {
    private fun m(en: List<String>, fa: List<String>) = mapOf(Lang.EN to en, Lang.FA to fa)

    private val keywords: Map<Topic, List<String>> = mapOf(
        Topic.MUSIC to listOf("song", "music", "album", "band", "guitar", "concert", "آهنگ", "موسیقی", "آلبوم", "خواننده", "کنسرت"),
        Topic.MOVIES to listOf("movie", "film", "cinema", "actor", "series", "فیلم", "سینما", "سریال", "بازیگر"),
        Topic.GAMES to listOf("game", "gaming", "console", "level", "بازی", "گیم", "کنسول", "مرحله"),
        Topic.POLITICS to listOf("election", "government", "politic", "vote", "parliament", "انتخابات", "دولت", "سیاست", "رأی", "رای", "مجلس"),
        Topic.NEWS to listOf("news", "breaking", "headline", "report", "خبر", "گزارش", "تیتر"),
        Topic.PHILOSOPHY to listOf("meaning", "truth", "philosoph", "mind", "free will", "معنی", "حقیقت", "فلسفه", "آزادی", "ذهن"),
        Topic.TECH to listOf("code", "phone", "tech", "bug", "robot", "gpt", "software", "کد", "گوشی", "تکنولوژی", "باگ", "هوش مصنوعی", "برنامه"),
        Topic.SPORTS to listOf("match", "football", "goal", "team", "sport", "فوتبال", "تیم", "گل", "ورزش", "مسابقه"),
        Topic.FOOD to listOf("food", "pizza", "coffee", "cook", "dinner", "غذا", "قهوه", "چای", "پیتزا", "کباب", "شام"),
        Topic.HUMOR to listOf("lol", "funny", "joke", "haha", "خنده", "جوک", "شوخی", "طنز"),
        Topic.LIFE to listOf("life", "happy", "sad", "love", "friend", "زندگی", "خوشحال", "غم", "عشق", "دوست")
    )

    private val tags: Map<Topic, Pair<String, String>> = mapOf(
        Topic.MUSIC to ("#music" to "#موسیقی"), Topic.MOVIES to ("#movies" to "#سینما"),
        Topic.GAMES to ("#gaming" to "#گیم"), Topic.POLITICS to ("#politics" to "#سیاست"),
        Topic.NEWS to ("#news" to "#خبر"), Topic.PHILOSOPHY to ("#thoughts" to "#فلسفه"),
        Topic.TECH to ("#tech" to "#تکنولوژی"), Topic.SPORTS to ("#sports" to "#ورزش"),
        Topic.FOOD to ("#food" to "#غذا"), Topic.HUMOR to ("#lol" to "#طنز"),
        Topic.LIFE to ("#life" to "#زندگی")
    )

    private val posts: Map<Topic, Map<Lang, List<String>>> = mapOf(
        Topic.MUSIC to m(
            listOf("That bassline in the second verse is doing things to my brain.", "Rewatching old live concerts instead of sleeping again.", "Hot take: the b-side is always better than the single."),
            listOf("بیس آهنگ دوم آلبوم جدید واقعاً یه چیز دیگه‌ست.", "دوباره ساعت سه شب افتادم به گوش دادن آهنگ‌های قدیمی.", "نظر من: آهنگ‌های بی‌سایدِ آلبوم همیشه از تک‌آهنگ‌ها بهترن.")),
        Topic.MOVIES to m(
            listOf("Just finished a movie I'm still thinking about. No spoilers, but wow.", "Every sequel is worse than the original. Prove me wrong.", "Underrated: movies with no CGI and a great script."),
            listOf("یه فیلم دیدم که هنوز بهش فکر می‌کنم. اسپویل نمی‌کنم ولی عالی بود.", "هر قسمت دوم از اولی ضعیف‌تره. کسی مخالفه؟", "فیلم بدون جلوه‌ی ویژه ولی با فیلمنامه‌ی خوب، همیشه بهترینه.")),
        Topic.GAMES to m(
            listOf("One more level and I'm going to bed. (Narrator: he did not go to bed.)", "Games used to be finished at release. Remember that?", "Difficulty settings are a good thing. Fight me."),
            listOf("فقط یه مرحله‌ی دیگه و می‌خوابم. (نخوابید.)", "قدیم‌ها بازی‌ها کامل منتشر می‌شدن، یادتونه؟", "درجه‌ی سختی انتخابی چیز خوبیه. بیاید بحث کنیم.")),
        Topic.POLITICS to m(
            listOf("Every debate about policy ends up being about tone instead of facts.", "Voting matters, but so does paying attention between elections.", "Complicated issues deserve more than a one-line slogan."),
            listOf("هر بحث سیاسی آخرش به لحن می‌رسه و از واقعیت‌ها دور می‌شیم.", "رأی دادن مهمه، ولی توجه بین دو انتخابات هم مهمه.", "مسائل پیچیده بیشتر از یک شعار یک‌خطی ارزش دارن.")),
        Topic.NEWS to m(
            listOf("BREAKING (simulated): local man discovers the Wi-Fi was working all along.", "Read the full article before sharing the headline, people.", "Headlines are getting longer and the news is getting shorter."),
            listOf("فوری (شبیه‌سازی): مردی کشف کرد که وای‌فای از اول سالم بوده.", "قبل از اشتراک تیتر، متن کامل خبر رو بخونید.", "تیترها بلندتر می‌شن و خبرها کوتاه‌تر.")),
        Topic.PHILOSOPHY to m(
            listOf("If you could pause time, would you still be the same person afterwards?", "Freedom is mostly the ability to choose your constraints.", "We spend our lives preparing to live. Strange, isn't it?"),
            listOf("اگه می‌تونستی زمان رو نگه داری، بعدش هنوز همون آدم قبلی بودی؟", "آزادی بیشتر یعنی توانایی انتخاب محدودیت‌هات.", "عمرمون رو صرف آماده شدن برای زندگی می‌کنیم. عجیب نیست؟")),
        Topic.TECH to m(
            listOf("My code worked yesterday. I changed nothing. Today it's on fire.", "AI is a great assistant and a terrible oracle.", "Phone batteries improve 2% a year and apps get 20% heavier."),
            listOf("کدم دیروز کار می‌کرد. هیچی عوض نکردم. امروز آتیش گرفته.", "هوش مصنوعی دستیار خوبیه ولی غیب‌گوی افتضاحیه.", "باتری گوشی سالی دو درصد بهتر می‌شه و برنامه‌ها بیست درصد سنگین‌تر.")),
        Topic.SPORTS to m(
            listOf("That last-minute goal just aged me ten years.", "Fans are the real twelfth player, and also the real critics.", "Training is boring. Results are not. Show up anyway."),
            listOf("اون گل دقیقه‌ی آخر ده سال پیرم کرد.", "هوادارها هم بازیکن دوازدهمن هم منتقد اصلی.", "تمرین خسته‌کننده‌ست ولی نتیجه نه. بازم برو.")),
        Topic.FOOD to m(
            listOf("Coffee first, personality later.", "Leftover pizza at midnight beats any five-star dinner.", "Cooking at home is cheaper, healthier, and 40% more dishes to wash."),
            listOf("اول قهوه، بعد شخصیت.", "پیتزای مانده‌ی نیمه‌شب از هر شام پنج‌ستاره‌ای بهتره.", "غذای خونگی ارزون‌تر و سالم‌تره، فقط ظرف شستنش چهل درصد بیشتره.")),
        Topic.HUMOR to m(
            listOf("I told my alarm clock we need to talk. It didn't snooze, it ghosted.", "My weekend plans: lie down, think about doing things.", "Adulthood is just googling how to do things with confidence."),
            listOf("به ساعت زنگ‌دارم گفتم باید حرف بزنیم. اون ساکت شد و منم خوابیدم.", "برنامه‌ی آخر هفته‌ام: دراز بکشم و به انجام دادن کارها فکر کنم.", "بزرگ‌سالی یعنی با اعتمادبه‌نفس چیزها رو گوگل کردن.")),
        Topic.LIFE to m(
            listOf("Small wins count. Drank water today. Proud of me.", "Sunsets are free and still undervalued.", "Be kind. Everyone is fighting a battle with their inbox."),
            listOf("پیروزی‌های کوچیک هم حساب می‌شن. امروز آب خوردم. به خودم افتخار می‌کنم.", "غروب آفتاب مجانیه و هنوز دست‌کم گرفته می‌شه.", "مهربون باشید. همه با صندوق ایمیلشون در جنگن."))
    )

    private val replies: Map<Stance, Map<Lang, List<String>>> = mapOf(
        Stance.SUPPORTIVE to m(
            listOf("Totally agree with you on {kw}!", "This is so true. Needed to hear it today.", "Well said. Sharing this with my friends."),
            listOf("کاملاً موافقم، درست گفتی!", "خیلی درسته. امروز لازمش داشتم.", "عالی گفتی، برای دوستام می‌فرستم.")),
        Stance.CONTRARIAN to m(
            listOf("Sorry, but I think you're wrong about {kw}.", "Hard disagree. It's more complicated than that.", "Unpopular opinion: this take doesn't hold up."),
            listOf("ببخشید ولی فکر می‌کنم اشتباه می‌کنی.", "کاملاً مخالفم، موضوع پیچیده‌تر از این حرفاست.", "نظر نامحبوب: این حرف زیاد منطقی نیست.")),
        Stance.SARCASTIC to m(
            listOf("Wow, such a fresh take. Nobody has ever said that before.", "Oh sure, because that always works out perfectly.", "Groundbreaking. Please write a book."),
            listOf("وای، چه حرف تازه‌ای. تا حالا هیچکس نگفته بود.", "آره بابا، مگه همیشه همین‌طوری نمی‌شه؟", "بی‌نظیر بود. یه کتاب بنویس.")),
        Stance.CURIOUS to m(
            listOf("Interesting. What made you think about {kw}?", "Can you explain more? I'm not sure I follow.", "Has anyone actually looked at the data on this?"),
            listOf("جالبه. چی شد که به این فکر کردی؟", "می‌شه بیشتر توضیح بدی؟ کامل نفهمیدم.", "کسی واقعاً آمارش رو دیده؟")),
        Stance.DEEP to m(
            listOf("Maybe the real question is why we care so much about this.", "Every opinion is a window and a wall at the same time.", "In the long run this will matter less than we think."),
            listOf("شاید سؤال اصلی اینه که چرا اینقدر بهش اهمیت می‌دیم.", "هر نظری هم پنجره‌ست هم دیوار.", "در بلندمدت این موضوع کم‌اهمیت‌تر از چیزیه که فکر می‌کنیم.")),
        Stance.NEUTRAL to m(
            listOf("Fair point, though I can see both sides.", "Saved this for later.", "Depends on the situation, honestly."),
            listOf("حرف قابل‌قبولیه، ولی هر دو طرف دلیل دارن.", "ذخیره کردم برای بعد.", "راستش بستگی به شرایط داره."))
    )

    fun isPersian(text: String) = text.any { it in '\u0600'..'\u06FF' }

    fun detectTopics(text: String): Set<Topic> {
        val t = text.lowercase()
        return keywords.filter { (_, ws) -> ws.any { t.contains(it) } }.keys
    }

    private fun keyword(text: String): String? {
        val t = text.lowercase()
        return keywords.values.flatten().firstOrNull { t.contains(it) }
    }

    /** Choose bots who care about the text's topic (+ same-language bias + randomness). */
    fun pickResponders(text: String, excludeId: String, n: Int): List<Persona> {
        val topics = detectTopics(text)
        val fa = isPersian(text)
        return Personas.all.filter { it.id != excludeId }
            .map { p ->
                val score = p.topics.count { it in topics } * 3.0 +
                    (if ((p.lang == Lang.FA) == fa) 1.5 else 0.0) +
                    Random.nextDouble() * 2.5
                p to score
            }
            .sortedByDescending { it.second }
            .take(n).map { it.first }
    }

    fun post(p: Persona): String {
        val topic = p.topics.randomOrNull() ?: Topic.LIFE
        var s = posts.getValue(topic).getValue(p.lang).random()
        if (Random.nextFloat() < 0.35f) {
            val tag = tags.getValue(topic).let { if (p.lang == Lang.EN) it.first else it.second }
            s += "\n$tag"
        }
        return s
    }

    fun reply(p: Persona, target: String): String {
        val stance = if (Random.nextFloat() < 0.25f) Stance.values().random() else p.stance
        val kw = keyword(target) ?: if (p.lang == Lang.FA) "این" else "this"
        return replies.getValue(stance).getValue(p.lang).random().replace("{kw}", kw)
    }
}
