package com.chirp.sim

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class SimViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).posts()
    private val rnd = Random.Default

    /** Swap this for an LLM-backed generator in step 4. */
    var generator: TextGenerator = TemplateGenerator

    var autoPost by mutableStateOf(true)
    var speed by mutableStateOf(1)   // 1x, 2x, 4x

    val feed = dao.feed().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val replyCounts = dao.replyCounts()
        .map { list -> list.associate { it.id to it.n } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    fun post(id: Long) = dao.observe(id)
    fun replies(id: Long) = dao.replies(id)

    init {
        viewModelScope.launch {
            if (dao.count() == 0) seed()
            autoLoop()
        }
    }

    // ---------- user actions ----------

    fun publish(text: String) = viewModelScope.launch {
        val id = dao.insert(PostEntity(authorId = Personas.USER.id, text = text))
        simulateLikes(id)
        react(id, text, Personas.USER.id, Personas.USER.handle, depth = 0, maxBots = 6)
    }

    fun reply(rootId: Long, toHandle: String, text: String) = viewModelScope.launch {
        dao.insert(PostEntity(authorId = Personas.USER.id, text = text, parentId = rootId, replyTo = toHandle))
        react(rootId, text, Personas.USER.id, Personas.USER.handle, depth = 0, maxBots = 3,
            forced = Personas.byHandle(toHandle))
    }

    fun toggleLike(p: PostEntity) = viewModelScope.launch {
        dao.setLike(p.id, if (p.likedByMe) -1 else 1, !p.likedByMe)
    }

    fun repost(p: PostEntity) = viewModelScope.launch { dao.repost(p.id) }

    fun resetAll() = viewModelScope.launch { dao.clear(); seed() }

    fun cycleSpeed() { speed = when (speed) { 1 -> 2; 2 -> 4; else -> 1 } }

    // ---------- simulation ----------

    private suspend fun seed() {
        val now = System.currentTimeMillis()
        Personas.all.shuffled().take(14).forEachIndexed { i, p ->
            dao.insert(
                PostEntity(
                    authorId = p.id,
                    text = safePost(p),
                    createdAt = now - (i + 1) * rnd.nextLong(120_000, 900_000),
                    likes = rnd.nextInt(0, 40),
                    reposts = rnd.nextInt(0, 8)
                )
            )
        }
    }

    private suspend fun autoLoop() {
        while (true) {
            delay(rnd.nextLong(8_000, 20_000) / speed)
            if (!autoPost) continue
            val p = Personas.all.random()
            val text = safePost(p)
            val id = dao.insert(PostEntity(authorId = p.id, text = text))
            if (rnd.nextFloat() < 0.6f) react(id, text, p.id, p.handle, depth = 1, maxBots = 3)
            dao.recent().randomOrNull()?.let { dao.addLikes(it.id, rnd.nextInt(1, 4)) }
        }
    }

    private fun simulateLikes(id: Long) = viewModelScope.launch {
        repeat(rnd.nextInt(2, 6)) {
            delay(rnd.nextLong(3_000, 10_000) / speed)
            dao.addLikes(id, rnd.nextInt(1, 4))
        }
    }

    /** Bots react to [text]; each reply may trigger follow-ups until depth 2 (debate chains). */
    private fun react(
        rootId: Long, text: String, authorId: String, handle: String,
        depth: Int, maxBots: Int, forced: Persona? = null
    ) {
        viewModelScope.launch {
            val picked = Engine.pickResponders(text, authorId, rnd.nextInt(1, maxBots + 1))
            val bots = (listOfNotNull(forced) + picked).distinctBy { it.id }.filter { it.id != authorId }
            bots.forEach { bot ->
                launch {
                    delay(rnd.nextLong(2_000, 9_000) / speed)
                    val reply = safeReply(bot, text)
                    dao.insert(PostEntity(authorId = bot.id, text = reply, parentId = rootId, replyTo = handle))
                    if (depth < 2 && rnd.nextFloat() < 0.4f) {
                        react(rootId, reply, bot.id, bot.handle, depth + 1, 2)
                    }
                }
            }
        }
    }

    private suspend fun safePost(p: Persona) =
        runCatching { generator.post(p) }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: TemplateGenerator.post(p)

    private suspend fun safeReply(p: Persona, target: String) =
        runCatching { generator.reply(p, target, emptyList()) }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: TemplateGenerator.reply(p, target, emptyList())
}
