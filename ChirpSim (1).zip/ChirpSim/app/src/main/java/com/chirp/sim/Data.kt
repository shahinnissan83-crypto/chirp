package com.chirp.sim

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Both top-level posts (parentId == null) and comments (parentId = root post id). */
@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val authorId: String,
    val text: String,
    val parentId: Long? = null,
    val replyTo: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val likes: Int = 0,
    val reposts: Int = 0,
    val likedByMe: Boolean = false
)

data class ReplyCount(val id: Long, val n: Int)

@Dao
interface PostDao {
    @Query("SELECT * FROM posts WHERE parentId IS NULL ORDER BY createdAt DESC LIMIT 300")
    fun feed(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE id = :id")
    fun observe(id: Long): Flow<PostEntity?>

    @Query("SELECT * FROM posts WHERE parentId = :id ORDER BY createdAt ASC")
    fun replies(id: Long): Flow<List<PostEntity>>

    @Query("SELECT parentId AS id, COUNT(*) AS n FROM posts WHERE parentId IS NOT NULL GROUP BY parentId")
    fun replyCounts(): Flow<List<ReplyCount>>

    @Query("SELECT COUNT(*) FROM posts")
    suspend fun count(): Int

    @Query("SELECT * FROM posts WHERE parentId IS NULL ORDER BY createdAt DESC LIMIT 20")
    suspend fun recent(): List<PostEntity>

    @Insert
    suspend fun insert(p: PostEntity): Long

    @Query("UPDATE posts SET likes = likes + :d, likedByMe = :liked WHERE id = :id")
    suspend fun setLike(id: Long, d: Int, liked: Boolean)

    @Query("UPDATE posts SET likes = likes + :d WHERE id = :id")
    suspend fun addLikes(id: Long, d: Int)

    @Query("UPDATE posts SET reposts = reposts + 1 WHERE id = :id")
    suspend fun repost(id: Long)

    @Query("DELETE FROM posts")
    suspend fun clear()
}

@Database(entities = [PostEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun posts(): PostDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "chirp.db")
                .build().also { inst = it }
        }
    }
}
