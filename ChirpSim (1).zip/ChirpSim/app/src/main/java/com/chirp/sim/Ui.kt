package com.chirp.sim

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

val Blue = Color(0xFF1D9BF0)
private val Pink = Color(0xFFF91880)

@Composable
fun ChirpTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(
            primary = Blue, background = Color.Black, surface = Color.Black,
            onBackground = Color(0xFFE7E9EA), onSurface = Color(0xFFE7E9EA),
            onSurfaceVariant = Color(0xFF71767B), outline = Color(0xFF2F3336)
        )
    else
        lightColorScheme(
            primary = Blue, background = Color.White, surface = Color.White,
            onSurfaceVariant = Color(0xFF536471), outline = Color(0xFFEFF3F4)
        )
    MaterialTheme(colorScheme = scheme, content = content)
}

fun timeAgo(t: Long): String {
    val s = (System.currentTimeMillis() - t) / 1000
    return when {
        s < 10 -> "now"
        s < 60 -> "${s}s"
        s < 3600 -> "${s / 60}m"
        s < 86400 -> "${s / 3600}h"
        else -> "${s / 86400}d"
    }
}

@Composable
fun App(vm: SimViewModel = viewModel()) {
    var openPost by remember { mutableStateOf<Long?>(null) }
    var composing by remember { mutableStateOf(false) }
    BackHandler(openPost != null) { openPost = null }

    val id = openPost
    if (id == null) FeedScreen(vm, onOpen = { openPost = it }, onCompose = { composing = true })
    else ThreadScreen(vm, id, onBack = { openPost = null })

    if (composing) ComposeDialog(
        onDismiss = { composing = false },
        onPost = { vm.publish(it); composing = false }
    )
}

@Composable
fun Avatar(p: Persona, size: Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Color(p.color)),
        contentAlignment = Alignment.Center
    ) { Text(p.emoji, fontSize = (size.value * 0.5f).sp) }
}

@Composable
fun Action(label: String, n: Int, active: Boolean = false, onClick: () -> Unit) {
    Text(
        "$label $n",
        fontSize = 14.sp,
        color = if (active) Pink else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

@Composable
fun PostCard(
    post: PostEntity, replies: Int,
    onOpen: (() -> Unit)?, onLike: () -> Unit, onRepost: () -> Unit
) {
    val p = Personas.byId(post.authorId)
    Column(
        Modifier.fillMaxWidth().then(if (onOpen != null) Modifier.clickable { onOpen() } else Modifier)
    ) {
        Row(Modifier.padding(12.dp)) {
            Avatar(p)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        p.name, fontWeight = FontWeight.Bold, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                    )
                    Text(
                        " @${p.handle} · ${timeAgo(post.createdAt)}", maxLines = 1,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp
                    )
                }
                post.replyTo?.let {
                    Text("Replying to @$it", color = Blue, fontSize = 13.sp)
                }
                Text(
                    post.text, fontSize = 16.sp,
                    style = LocalTextStyle.current.copy(textDirection = TextDirection.Content)
                )
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Action("💬", replies) { onOpen?.invoke() }
                    Action("🔁", post.reposts, onClick = onRepost)
                    Action(if (post.likedByMe) "♥" else "♡", post.likes, post.likedByMe, onLike)
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(vm: SimViewModel, onOpen: (Long) -> Unit, onCompose: () -> Unit) {
    val feed by vm.feed.collectAsState()
    val counts by vm.replyCounts.collectAsState()
    var menu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Chirp 🐦", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.Settings, "Settings") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Auto posts: ${if (vm.autoPost) "on" else "off"}") },
                            onClick = { vm.autoPost = !vm.autoPost }
                        )
                        DropdownMenuItem(
                            text = { Text("Speed: ${vm.speed}x") },
                            onClick = { vm.cycleSpeed() }
                        )
                        DropdownMenuItem(
                            text = { Text("Reset everything") },
                            onClick = { vm.resetAll(); menu = false }
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCompose, containerColor = Blue, contentColor = Color.White) {
                Icon(Icons.Default.Add, "New post")
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            items(feed, key = { it.id }) { post ->
                PostCard(
                    post, counts[post.id] ?: 0,
                    onOpen = { onOpen(post.id) },
                    onLike = { vm.toggleLike(post) },
                    onRepost = { vm.repost(post) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreadScreen(vm: SimViewModel, rootId: Long, onBack: () -> Unit) {
    val root by remember(rootId) { vm.post(rootId) }.collectAsState(initial = null)
    val replies by remember(rootId) { vm.replies(rootId) }.collectAsState(initial = emptyList())
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf<String?>(null) }
    val rootHandle = root?.let { Personas.byId(it.authorId).handle } ?: "you"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Post", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        },
        bottomBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.background)) {
                Text(
                    "Replying to @${target ?: rootHandle}" + if (target != null) "  ✕" else "",
                    color = Blue, fontSize = 13.sp,
                    modifier = Modifier.clickable { target = null }.padding(horizontal = 12.dp, vertical = 4.dp)
                )
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text, onValueChange = { if (it.length <= 280) text = it },
                        modifier = Modifier.weight(1f), maxLines = 4,
                        placeholder = { Text("Post your reply") }
                    )
                    IconButton(onClick = {
                        if (text.isNotBlank()) {
                            vm.reply(rootId, target ?: rootHandle, text.trim())
                            text = ""; target = null
                        }
                    }) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Blue) }
                }
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            root?.let { r ->
                item(key = "root") {
                    PostCard(r, replies.size, null, { vm.toggleLike(r) }, { vm.repost(r) })
                }
            }
            items(replies, key = { it.id }) { c ->
                val h = Personas.byId(c.authorId).handle
                PostCard(
                    c, 0,
                    onOpen = { if (h != "you") target = h },
                    onLike = { vm.toggleLike(c) },
                    onRepost = { vm.repost(c) }
                )
            }
        }
    }
}

@Composable
fun ComposeDialog(onDismiss: () -> Unit, onPost: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New post") },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { if (it.length <= 280) text = it },
                modifier = Modifier.fillMaxWidth(), minLines = 3,
                placeholder = { Text("What's happening?") },
                supportingText = { Text("${text.length}/280") }
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onPost(text.trim()) }) { Text("Post") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
