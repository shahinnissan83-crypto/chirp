package com.chirp.sim

enum class Topic { MUSIC, MOVIES, GAMES, POLITICS, NEWS, PHILOSOPHY, TECH, SPORTS, FOOD, HUMOR, LIFE }
enum class Stance { SUPPORTIVE, CONTRARIAN, SARCASTIC, CURIOUS, DEEP, NEUTRAL }
enum class Lang { FA, EN }

data class Persona(
    val id: String,
    val name: String,
    val handle: String,
    val bio: String,
    val lang: Lang,
    val emoji: String,
    val color: Long,
    val topics: List<Topic>,
    val stance: Stance
)

object Personas {
    val USER = Persona("me", "You", "you", "That's you", Lang.EN, "🙂", 0xFF1D9BF0, emptyList(), Stance.NEUTRAL)

    private fun p(
        h: String, name: String, lang: Lang, emoji: String, color: Long,
        stance: Stance, bio: String, vararg t: Topic
    ) = Persona(h, name, h, bio, lang, emoji, color, t.toList(), stance)

    val all: List<Persona> = listOf(
        // ---- English ----
        p("maya_beats", "Maya Chen", Lang.EN, "🎧", 0xFF7E57C2, Stance.SUPPORTIVE, "Vinyl, synths and late-night playlists.", Topic.MUSIC, Topic.HUMOR),
        p("carl_reels", "Cinephile Carl", Lang.EN, "🎬", 0xFFD84315, Stance.CONTRARIAN, "Film snob. Yes, I've seen the director's cut.", Topic.MOVIES),
        p("pixelpete", "Pixel Pete", Lang.EN, "🎮", 0xFF2E7D32, Stance.SUPPORTIVE, "Gamer, streamer, part-time speedrunner.", Topic.GAMES, Topic.TECH),
        p("civic_sam", "Sam Rivers", Lang.EN, "🏛️", 0xFF455A64, Stance.CURIOUS, "Policy nerd. Questions > slogans.", Topic.POLITICS, Topic.NEWS),
        p("dispatch_now", "Daily Dispatch", Lang.EN, "📰", 0xFF37474F, Stance.NEUTRAL, "Headlines, simulated.", Topic.NEWS),
        p("elena_thinks", "Elena the Sage", Lang.EN, "🦉", 0xFF6D4C41, Stance.DEEP, "Thinking out loud about everything.", Topic.PHILOSOPHY, Topic.LIFE),
        p("devdan", "Dev Dan", Lang.EN, "💻", 0xFF00838F, Stance.SARCASTIC, "It works on my machine.", Topic.TECH),
        p("coach_rick", "Coach Rick", Lang.EN, "⚽", 0xFF1565C0, Stance.SUPPORTIVE, "Sports, sweat and second halves.", Topic.SPORTS),
        p("lila_eats", "Chef Lila", Lang.EN, "🍕", 0xFFEF6C00, Stance.SUPPORTIVE, "Cooking, eating, repeating.", Topic.FOOD, Topic.LIFE),
        p("sirsarcasm", "Sir Sarcasm", Lang.EN, "🙄", 0xFF8E24AA, Stance.SARCASTIC, "Professional eye-roller.", Topic.HUMOR, Topic.NEWS, Topic.TECH),
        p("grumpy_gus", "Grumpy Gus", Lang.EN, "😒", 0xFF5D4037, Stance.CONTRARIAN, "Back in my day things worked.", Topic.NEWS, Topic.POLITICS, Topic.LIFE),
        p("ava_rose", "Ava Rose", Lang.EN, "🌸", 0xFFEC407A, Stance.SUPPORTIVE, "Positivity, tea and good songs.", Topic.LIFE, Topic.MUSIC),
        p("quinn_asks", "Quinn", Lang.EN, "🤔", 0xFF3949AB, Stance.CURIOUS, "Always asking why.", Topic.PHILOSOPHY, Topic.TECH),
        p("retro_ron", "Retro Ron", Lang.EN, "🕹️", 0xFF6A1B9A, Stance.NEUTRAL, "The 90s were fine, thanks.", Topic.GAMES, Topic.MOVIES, Topic.MUSIC),
        // ---- Persian ----
        p("sara_music", "سارا موزیک", Lang.FA, "🎵", 0xFFAD1457, Stance.SUPPORTIVE, "عاشق موسیقی و پلی‌لیست‌های نیمه‌شب.", Topic.MUSIC, Topic.LIFE),
        p("film_naghed", "منتقد فیلم", Lang.FA, "🎞️", 0xFFBF360C, Stance.CONTRARIAN, "هیچ فیلمی به اندازه‌ی کافی خوب نیست.", Topic.MOVIES),
        p("gamer_ali", "گیمر علی", Lang.FA, "🎮", 0xFF1B5E20, Stance.SUPPORTIVE, "بازی، بازی و باز هم بازی.", Topic.GAMES, Topic.TECH),
        p("tahlilgar", "تحلیل‌گر", Lang.FA, "🧭", 0xFF37474F, Stance.CURIOUS, "سؤال می‌پرسم، شعار نمی‌دم.", Topic.POLITICS, Topic.NEWS),
        p("khabar_fori", "خبر فوری", Lang.FA, "📢", 0xFFB71C1C, Stance.NEUTRAL, "خبرهای شبیه‌سازی‌شده.", Topic.NEWS),
        p("shab_falsafe", "فیلسوف شب", Lang.FA, "🌙", 0xFF283593, Stance.DEEP, "ساعت سه شب بهترین وقت فکر کردنه.", Topic.PHILOSOPHY, Topic.LIFE),
        p("reza_dev", "برنامه‌نویس رضا", Lang.FA, "🧑‍💻", 0xFF006064, Stance.SARCASTIC, "روی سیستم من که کار می‌کنه.", Topic.TECH),
        p("football_baz", "فوتبالی", Lang.FA, "⚽", 0xFF0D47A1, Stance.CONTRARIAN, "داور همیشه اشتباه می‌کنه.", Topic.SPORTS),
        p("maryam_cooks", "آشپز مریم", Lang.FA, "🍲", 0xFFE65100, Stance.SUPPORTIVE, "دستپخت و دورهمی.", Topic.FOOD, Topic.LIFE),
        p("tanz_pardaz", "طنزپرداز", Lang.FA, "😂", 0xFF6A1B9A, Stance.SARCASTIC, "جدی نگیرید.", Topic.HUMOR, Topic.NEWS),
        p("badbin", "بدبین", Lang.FA, "😑", 0xFF4E342E, Stance.CONTRARIAN, "همیشه یه چیزی خراب می‌شه.", Topic.NEWS, Topic.POLITICS, Topic.LIFE),
        p("mehrabon", "مهربون", Lang.FA, "🌷", 0xFFD81B60, Stance.SUPPORTIVE, "مهربونی رایگانه.", Topic.LIFE, Topic.MUSIC),
        p("konjkav", "کنجکاو", Lang.FA, "🔎", 0xFF303F9F, Stance.CURIOUS, "چرا؟ از کجا؟ به چه دلیل؟", Topic.TECH, Topic.PHILOSOPHY),
        p("ghadimi_ha", "قدیمی‌ها", Lang.FA, "📻", 0xFF795548, Stance.NEUTRAL, "نوستالژی تا ابد.", Topic.MUSIC, Topic.MOVIES)
    )

    private val map = all.associateBy { it.id }
    fun byId(id: String): Persona = if (id == USER.id) USER else map[id] ?: USER
    fun byHandle(h: String): Persona? = all.firstOrNull { it.handle == h }
}
